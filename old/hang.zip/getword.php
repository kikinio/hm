<?php
$q = intval($_GET['q']);

$con = mysqli_connect('localhost','Testuser','abc123','users');
if (!$con) {
    die('Could not connect: ' . mysqli_error($con));
}

mysqli_select_db($con,"users");
//$sql="SELECT * FROM user WHERE id = '".$q."'";

$sql="SELECT word FROM words where id = '".$q."'";

$result = mysqli_query($con,$sql);
$row = mysqli_fetch_array($result);
echo $row['word'];
?>