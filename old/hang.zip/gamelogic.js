var word = 'liverpool';
var e = document.getElementById("setLives");
var initialLives = e.options[e.selectedIndex].value;

function selectLives() {
	e = document.getElementById("setLives");
	initialLives = e.options[e.selectedIndex].value;
	lives = initialLives;
	
	document.getElementById("livesMessage").innerHTML = "You have " + initialLives + " lives left!";
	document.getElementById("setLives").style.pointerEvents = "none";
	
	
	ranWordID = Math.floor((Math.random() * 284) + 1);
	getWord(ranWordID);
	//word = getWord(ranWordID);
	len = getWord(ranWordID).length;
	currentWord = nwordbox();
	document.getElementById("nword").innerHTML = currentWord;
	consLObjAll();
	consL();
	return initialLives;
}

/*
function getWord(str) {
    if (str == "") {
        word = 'liverpool';
        return;
    } else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                word = xmlhttp.responseText;
            }
        };
        xmlhttp.open("POST","getword.php?q="+str,true); //true не работи добре :) ???
        xmlhttp.send();
    }
	return word;
}
*/
function getWord(str) {
		xmlhttp = new XMLHttpRequest();
        xmlhttp.open("POST","getword.php?q="+str,false);
        xmlhttp.send();
		word = xmlhttp.responseText;
    	return word;
}


//initialLives = selectLives();
console.log("initialLives");
var lives = initialLives;
var numPic = 10;
changePic();
console.log("word:", word);
console.log(word);
console.log("lives");
console.log(lives);
var len = word.length;
var currentWord = nwordbox();
document.getElementById("nword").innerHTML = currentWord;
document.getElementById("livesMessage").innerHTML = "You have " + lives + " lives left!";
var numPic = changePic();
//var car = {type:"Fiat", model:"500", color:"white"};
//document.getElementById("demo").innerHTML = car.type;
var objectsAll = {word: word, initialLives: initialLives, lives: lives, len: len, currentWord: currentWord, numPic: numPic};
consLObjAll();
consL();
function nwordbox(){
console.log(len);
var currentWord = '';
for (var i = 0; i < len; i++){
	currentWord += "*";
	console.log("curWord");
	console.log(currentWord);
}
consLObjAll();
consL();
return currentWord;
}
function cli1(letter){
	console.log(letter);

	document.getElementById("test").innerHTML = letter;
	var e = document.getElementById("setLives");
	var initialLives = e.options[e.selectedIndex].value;
	//verification(letter, currentWord);
	currentWord = verification(letter, currentWord);
//	initialLives = selectLives();
//	lives = initialLives;
	numPic = changePic();
	consLObjAll();
	consL();
}
function verification(letter, cw){
	console.log(word);
	console.log(word.indexOf(letter)===-1);
	console.log(word.indexOf(letter));
	document.getElementById(letter).disabled = 1;
    if (word.indexOf(letter)=== -1){		
		lives -= 1;
		changePic();
	}else{
		for (var j = 0; j < len; j++) {
			if (letter === word[j]){
			cw = cw.substring(0, j) + letter + cw.substring(j+1);
			console.log(cw);
			document.getElementById("nword").innerHTML = cw;
			}
		}
	}
	if (cw === word){
		document.getElementById("livesMessage").innerHTML = "YOU WON THE GAME!!!";
		document.getElementById("buttons").style.pointerEvents = "none";
	}else{
	switch(lives) {
    case 0:
        changePic();
		document.getElementById("livesMessage").innerHTML = "GAME LOST!!! THE WORD IS: " + word.toUpperCase();
		document.getElementById("buttons").style.color="red";
		document.getElementById("buttons").style.pointerEvents = "none";
        break;
    default:
		//changePic();
        document.getElementById("livesMessage").innerHTML = "You have " + lives + " lives left!";
	}
	}
	consLObjAll();
	consL();
	return cw;
}
function changePic(){
		var numPic = initialLives - lives+1;
		document.getElementById("picture").src="images/lives" + initialLives + "/ss" + numPic + ".gif";
		return numPic;
		consLObjAll();
		consL();
}
function consL(){
	
	console.log("word:", word, "initialLives:", initialLives, "lives:", lives, "len:", len, "currentWord:", currentWord, "numPic:", numPic);
}
function consLObjAll(){
	objectsAll = {word: word, initialLives: initialLives, lives: lives, len: len, currentWord: currentWord, numPic: numPic};
	console.log(objectsAll);
};